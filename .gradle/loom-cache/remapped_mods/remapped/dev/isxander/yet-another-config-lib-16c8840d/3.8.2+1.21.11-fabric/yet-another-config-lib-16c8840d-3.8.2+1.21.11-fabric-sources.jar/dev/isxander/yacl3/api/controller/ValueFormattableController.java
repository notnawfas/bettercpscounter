package dev.isxander.yacl3.api.controller;

import java.util.function.Function;
import net.minecraft.text.Text;

public interface ValueFormattableController<T, B extends ValueFormattableController<T, B>> extends ControllerBuilder<T> {
    B formatValue(ValueFormatter<T> formatter);

    @Deprecated
    default B valueFormatter(Function<T, Text> formatter) {
        return formatValue(formatter::apply);
    }
}
