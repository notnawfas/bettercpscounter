package dev.isxander.yacl3.gui;

import dev.isxander.yacl3.gui.image.ImageRenderer;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.screen.narration.NarrationPart;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.GlfwUtil;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

public class OptionDescriptionWidget extends ClickableWidget {
    private static final int AUTO_SCROLL_TIMER = 1500;
    private static final float AUTO_SCROLL_SPEED = 1; // lines per second

    private @Nullable DescriptionWithName description;
    private List<OrderedText> wrappedText;

    private static final MinecraftClient minecraft = MinecraftClient.getInstance();
    private static final TextRenderer font = minecraft.textRenderer;

    private Supplier<ScreenRect> dimensions;

    private float targetScrollAmount, currentScrollAmount;
    private int maxScrollAmount;
    private int descriptionY;

    private int lastInteractionTime;
    private boolean scrollingBackward;

    public OptionDescriptionWidget(Supplier<ScreenRect> dimensions, @Nullable DescriptionWithName description) {
        super(0, 0, 0, 0, description == null ? Text.empty() : description.name());
        this.dimensions = dimensions;
        this.setOptionDescription(description);
    }

    @Override
    public void renderWidget(DrawContext graphics, int mouseX, int mouseY, float delta) {
        if (description == null) return;

        currentScrollAmount = MathHelper.lerp(delta * 0.5f, currentScrollAmount, targetScrollAmount);

        ScreenRect dimensions = this.dimensions.get();
        this.setX(dimensions.getLeft());
        this.setY(dimensions.getTop());
        this.width = dimensions.width();
        this.height = dimensions.height();

        int y = getY();

        int nameWidth = font.getWidth(description.name());
        if (nameWidth > getWidth()) {
            //? if >=1.21.11 {
            graphics.getHoverListener(this, DrawContext.HoverType.TOOLTIP_ONLY)
                    .text(description.name(), getX(), getX() + getWidth(), y, y + font.fontHeight);
            //?} else {
            /*renderScrollingString(graphics, font, description.name(), getX(), y, getX() + getWidth(), y + font.lineHeight, -1);
            *///?}
        } else {
            graphics.drawTextWithShadow(font, description.name(), getX(), y, 0xFFFFFFFF);
        }

        y += 5 + font.fontHeight;

        graphics.enableScissor(getX(), y, getX() + getWidth(), getY() + getHeight());

        y -= (int)currentScrollAmount;

        if (description.description().image().isDone()) {
            var image = description.description().image().join();
            if (image.isPresent()) {
                y += image.get().render(graphics, getX(), y, getWidth(), delta) + 5;
            }
        }

        if (wrappedText == null)
            wrappedText = font.wrapLines(description.description().text(), getWidth());

        descriptionY = y;
        for (var line : wrappedText) {
            //? if >=1.21.11 {
            graphics.getTextConsumer(DrawContext.HoverType.TOOLTIP_AND_CURSOR)
                    .text(getX(), y, line);
            //?} else {
            /*graphics.drawString(font, line, getX(), y, 0xFFFFFFFF);
            *///?}
            y += font.fontHeight;
        }

        graphics.disableScissor();

        maxScrollAmount = Math.max(0, y + (int)currentScrollAmount - getY() - getHeight());

        if (isSelected()) {
            lastInteractionTime = currentTimeMS();
        }
        Style hoveredStyle = getDescStyle(mouseX, mouseY);
        if (hoveredStyle != null && hoveredStyle.getHoverEvent() != null) {
            graphics.drawHoverEvent(font, hoveredStyle, mouseX, mouseY);
        }

        if (isFocused()) {
            graphics./*? if >=1.21.9 && <1.21.11 {*//*submitOutline*//*?} else {*/drawStrokedRectangle/*?}*/(getX(), getY(), getWidth(), getHeight(), -1);
        }
    }

    //? if >=1.21.9 {
    @Override
    public boolean mouseClicked(Click mouseButtonEvent, boolean bl) {
        return this.onMouseClicked(mouseButtonEvent.x(), mouseButtonEvent.y());
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return this.onMouseClicked(mouseX, mouseY);
    }
    *///?}

    protected boolean onMouseClicked(double mouseX, double mouseY) {
        Style clickedStyle = getDescStyle((int) mouseX, (int) mouseY);
        if (clickedStyle != null && clickedStyle.getClickEvent() != null) {
            // TODO: reimplement
            //? if <1.21.11 {
            /*if (minecraft.screen.handleComponentClicked(clickedStyle)) {
                playDownSound(minecraft.getSoundManager());
                return true;
            }
            *///?}
            return false;
        }

        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        if (isMouseOver(mouseX, mouseY)) {
            targetScrollAmount = MathHelper.clamp(targetScrollAmount - (int) vertical * 10, 0, maxScrollAmount);
            lastInteractionTime = currentTimeMS();
            return true;
        }
        return false;
    }

    //? if >=1.21.9 {
    @Override
    public boolean keyPressed(KeyInput keyEvent) {
        return this.onKeyPressed(keyEvent.key());
    }
    //?} else {
    /*@Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return this.onKeyPressed(keyCode);
    }
    *///?}
    protected boolean onKeyPressed(int keyCode) {
        if (isFocused()) {
            switch (keyCode) {
                case InputUtil.GLFW_KEY_UP ->
                        targetScrollAmount = MathHelper.clamp(targetScrollAmount - 10, 0, maxScrollAmount);
                case InputUtil.GLFW_KEY_DOWN ->
                        targetScrollAmount = MathHelper.clamp(targetScrollAmount + 10, 0, maxScrollAmount);
                default -> {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public void tick() {
        if (description != null) {
            description.description().image()
                    .getNow(Optional.empty())
                    .ifPresent(ImageRenderer::tick);
        }

        float pxPerTick = AUTO_SCROLL_SPEED / 20f * font.fontHeight;
        if (maxScrollAmount > 0 && currentTimeMS() - lastInteractionTime > AUTO_SCROLL_TIMER) {
            if (scrollingBackward) {
                pxPerTick *= -1;
                if (targetScrollAmount + pxPerTick < 0) {
                    scrollingBackward = false;
                    lastInteractionTime = currentTimeMS();
                }
            } else {
                if (targetScrollAmount + pxPerTick > maxScrollAmount) {
                    scrollingBackward = true;
                    lastInteractionTime = currentTimeMS();
                }
            }

            targetScrollAmount = MathHelper.clamp(targetScrollAmount + pxPerTick, 0, maxScrollAmount);
        }
    }

    private Style getDescStyle(int mouseX, int mouseY) {
        boolean clicked = /*? if >=1.21.4 {*/ isMouseOver(mouseX, mouseY) /*?} else {*/ /*clicked(mouseX, mouseY) *//*?}*/;
        if (!clicked)
            return null;

        int x = mouseX - getX();
        int y = mouseY - descriptionY;

        if (x < 0 || x > getX() + getWidth()) return null;
        if (y < 0 || y > getY() + getHeight()) return null;

        int line = y / font.fontHeight;

        if (line >= wrappedText.size()) return null;

        // TODO reimplement
        //? if >=1.21.11 {
        return null;
        //?} else {
        /*return font.getSplitter().componentStyleAtWidth(wrappedText.get(line), x);
        *///?}
    }

    @Override
    protected void appendClickableNarrations(NarrationMessageBuilder builder) {
        if (description != null) {
            builder.put(NarrationPart.TITLE, description.name());
            builder.put(NarrationPart.HINT, description.description().text());
        }

    }

    public void setOptionDescription(DescriptionWithName description) {
        this.description = description;
        this.wrappedText = null;
        this.targetScrollAmount = 0;
        this.currentScrollAmount = 0;
        this.lastInteractionTime = currentTimeMS();
    }

    private int currentTimeMS() {
        return (int)(GlfwUtil.getTime() * 1000);
    }

    @Nullable
    @Override
    public GuiNavigationPath getNavigationPath(GuiNavigation event) {
        // prevents focusing on this widget
        return null;
    }

}
