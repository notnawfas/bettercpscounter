package dev.isxander.yacl3.gui;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;

public class TooltipButtonWidget extends /*? if >=1.21.11 {*/ButtonWidget.Text/*?} else {*//*Button*//*?}*/ {

    protected final Screen screen;

    public TooltipButtonWidget(Screen screen, int x, int y, int width, int height, net.minecraft.text.Text message, net.minecraft.text.Text tooltip, PressAction onPress) {
        super(x, y, width, height, message, onPress, DEFAULT_NARRATION_SUPPLIER);
        this.screen = screen;
        if (tooltip != null)
            setTooltip(Tooltip.of(tooltip));
    }
}
