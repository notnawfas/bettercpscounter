package dev.isxander.yacl3.gui;

import net.minecraft.client.gui.widget.ClickableWidget;

public interface WidgetAndType<T> {
    T getType();

    ClickableWidget getWidget();

    static <T extends ClickableWidget> WidgetAndType<T> ofWidget(T widget) {
        return new WidgetAndType<>() {
            @Override
            public T getType() {
                return widget;
            }

            @Override
            public ClickableWidget getWidget() {
                return widget;
            }
        };
    }
}
