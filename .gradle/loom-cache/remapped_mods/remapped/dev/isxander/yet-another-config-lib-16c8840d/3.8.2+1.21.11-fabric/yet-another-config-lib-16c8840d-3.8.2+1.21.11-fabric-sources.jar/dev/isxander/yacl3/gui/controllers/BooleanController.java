package dev.isxander.yacl3.gui.controllers;

import dev.isxander.yacl3.api.Controller;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.controller.ValueFormatter;
import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.AbstractWidget;
import dev.isxander.yacl3.gui.YACLScreen;
import org.jetbrains.annotations.ApiStatus;

import java.util.function.Function;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * This controller renders a simple formatted {@link Text}
 */
public class BooleanController implements Controller<Boolean> {

    public static final Function<Boolean, Text> ON_OFF_FORMATTER = (state) ->
            state
                    ? ScreenTexts.ON
                    : ScreenTexts.OFF;

    public static final Function<Boolean, Text> TRUE_FALSE_FORMATTER = (state) ->
            state
                    ? Text.translatable("yacl.control.boolean.true")
                    : Text.translatable("yacl.control.boolean.false");

    public static final Function<Boolean, Text> YES_NO_FORMATTER = (state) ->
            state
                    ? ScreenTexts.YES
                    : ScreenTexts.NO;

    private final Option<Boolean> option;
    private final ValueFormatter<Boolean> valueFormatter;
    private final boolean coloured;

    /**
     * Constructs a tickbox controller
     * with the default value formatter of {@link BooleanController#ON_OFF_FORMATTER}
     *
     * @param option bound option
     */
    public BooleanController(Option<Boolean> option) {
        this(option, ON_OFF_FORMATTER, false);
    }

    /**
     * Constructs a tickbox controller
     * with the default value formatter of {@link BooleanController#ON_OFF_FORMATTER}
     *
     * @param option bound option
     * @param coloured value format is green or red depending on the state
     */
    public BooleanController(Option<Boolean> option, boolean coloured) {
        this(option, ON_OFF_FORMATTER, coloured);
    }

    /**
     * Constructs a tickbox controller
     *
     * @param option bound option
     * @param valueFormatter format value into any {@link Text}
     * @param coloured value format is green or red depending on the state
     */
    public BooleanController(Option<Boolean> option, Function<Boolean, Text> valueFormatter, boolean coloured) {
        this.option = option;
        this.valueFormatter = valueFormatter::apply;
        this.coloured = coloured;
    }

    @ApiStatus.Internal
    public static BooleanController createInternal(Option<Boolean> option, ValueFormatter<Boolean> formatter, boolean coloured) {
        return new BooleanController(option, formatter::format, coloured);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Option<Boolean> option() {
        return option;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Text formatValue() {
        return valueFormatter.format(option().pendingValue());
    }

    /**
     * Value format is green or red depending on the state
     */
    public boolean coloured() {
        return coloured;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public AbstractWidget provideWidget(YACLScreen screen, Dimension<Integer> widgetDimension) {
        return new BooleanControllerElement(this, screen, widgetDimension);
    }

    public static class BooleanControllerElement extends ControllerWidget<BooleanController> {
        public BooleanControllerElement(BooleanController control, YACLScreen screen, Dimension<Integer> dim) {
            super(control, screen, dim);
        }

        @Override
        protected void drawHoveredControl(DrawContext graphics, int mouseX, int mouseY, float delta) {

        }

        @Override
        protected void drawValueText(DrawContext graphics, int mouseX, int mouseY, float delta) {
            super.drawValueText(graphics, mouseX, mouseY, delta);

            if (hovered) {
                //? if >=1.21.9
                graphics.setCursor(isAvailable() ? net.minecraft.client.gui.cursor.StandardCursors.POINTING_HAND : net.minecraft.client.gui.cursor.StandardCursors.NOT_ALLOWED);
            }
        }

        @Override
        public boolean onMouseClicked(double mouseX, double mouseY, int button) {
            if (!isMouseOver(mouseX, mouseY) || !isAvailable())
                return false;

            toggleSetting();
            return true;
        }

        @Override
        protected int getHoveredControlWidth() {
            return getUnhoveredControlWidth();
        }

        public void toggleSetting() {
            control.option().requestSet(!control.option().pendingValue());
            playDownSound();
        }

        @Override
        protected Text getValueText() {
            if (control.coloured()) {
                return super.getValueText().copy().formatted(control.option().pendingValue() ? Formatting.GREEN : Formatting.RED);
            }

            return super.getValueText();
        }

        @Override
        public boolean onKeyPressed(int keyCode, int scanCode, int modifiers) {
            if (!isFocused()) {
                return false;
            }

            if (keyCode == InputUtil.GLFW_KEY_ENTER || keyCode == InputUtil.GLFW_KEY_SPACE || keyCode == InputUtil.GLFW_KEY_KP_ENTER) {
                toggleSetting();
                return true;
            }

            return false;
        }
    }
}
