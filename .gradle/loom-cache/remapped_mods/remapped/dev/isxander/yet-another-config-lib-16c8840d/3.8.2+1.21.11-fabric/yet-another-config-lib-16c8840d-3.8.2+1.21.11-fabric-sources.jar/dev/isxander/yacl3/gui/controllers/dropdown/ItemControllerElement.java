package dev.isxander.yacl3.gui.controllers.dropdown;

import dev.isxander.yacl3.api.utils.Dimension;
import dev.isxander.yacl3.gui.YACLScreen;
import dev.isxander.yacl3.gui.utils.ItemRegistryHelper;
import dev.isxander.yacl3.gui.utils.MiscUtil;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ItemControllerElement extends AbstractDropdownControllerElement<Item, Identifier> {
	private final ItemController itemController;
	protected Item currentItem = null;
	protected Map<Identifier, Item> matchingItems = new HashMap<>();


	public ItemControllerElement(ItemController control, YACLScreen screen, Dimension<Integer> dim) {
		super(control, screen, dim);
		this.itemController = control;
	}

	@Override
	protected void drawValueText(DrawContext graphics, int mouseX, int mouseY, float delta) {
		var oldDimension = getDimension();
		setDimension(getDimension().withWidth(getDimension().width() - getDecorationPadding()));
		super.drawValueText(graphics, mouseX, mouseY, delta);
		setDimension(oldDimension);
		if (currentItem != null) {
			graphics.drawItemWithoutEntity(new ItemStack(currentItem), getDimension().xLimit() - getXPadding() - getDecorationPadding() + 2, getDimension().y() + 2);
		}
	}

	@Override
	public List<Identifier> computeMatchingValues() {
		List<Identifier> identifiers = ItemRegistryHelper.getMatchingItemIdentifiers(inputField).toList();
		currentItem = ItemRegistryHelper.getItemFromName(inputField, null);
		for (Identifier identifier : identifiers) {
			matchingItems.put(identifier, MiscUtil.getFromRegistry(Registries.ITEM, identifier));
		}
		return identifiers;
	}

	@Override
	protected void renderDropdownEntry(DrawContext graphics, Dimension<Integer> entryDimension, Identifier identifier) {
		super.renderDropdownEntry(graphics, entryDimension, identifier);
		graphics.drawItemWithoutEntity(
				new ItemStack(matchingItems.get(identifier)),
				entryDimension.xLimit() - 2,
				entryDimension.y() + 1
		);
	}

	@Override
	public String getString(Identifier identifier) {
		return identifier.toString();
	}

	@Override
	protected int getDecorationPadding() {
		return 16;
	}

	@Override
	protected int getDropdownEntryPadding() {
		return 4;
	}

	@Override
	protected int getControlWidth() {
		return super.getControlWidth() + getDecorationPadding();
	}

	@Override
	protected Text getValueText() {
		if (inputField.isEmpty() || itemController == null)
			return super.getValueText();

		if (inputFieldFocused)
			return Text.literal(inputField);

		return itemController.option().pendingValue()
                //? if >=1.21.2 {
                .getName();
                //?} else {
                /*.getDescription();
                *///?}
	}
}
