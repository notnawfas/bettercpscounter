package dev.isxander.yacl3.gui.image;

import net.minecraft.client.gui.DrawContext;

public interface ImageRenderer {
    int render(DrawContext graphics, int x, int y, int renderWidth, float tickDelta);

    void close();

    default void tick() {}
}
