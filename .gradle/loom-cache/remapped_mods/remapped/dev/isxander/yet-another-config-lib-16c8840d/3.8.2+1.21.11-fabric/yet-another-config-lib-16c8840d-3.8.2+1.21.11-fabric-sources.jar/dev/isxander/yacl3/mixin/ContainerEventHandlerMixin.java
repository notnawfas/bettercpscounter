package dev.isxander.yacl3.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import org.spongepowered.asm.mixin.Mixin;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import net.minecraft.client.gui.ParentElement;
import net.minecraft.client.gui.navigation.NavigationAxis;
import net.minecraft.client.gui.navigation.NavigationDirection;
import net.minecraft.client.gui.widget.TabNavigationWidget;

@Mixin(ParentElement.class)
public interface ContainerEventHandlerMixin {
     // This mixin is used to prevent the tab bar from being focused when navigating left or right
     // through the YACL options screen. This can also apply to vanilla as navigating left or right
     // should never result in focusing the always-at-the-top tab bar.
     // Without this, navigating right from the option list focuses the tab bar, not the action buttons/description.
    @Redirect(
            method = {"nextFocusPathVaguelyInDirection", "nextFocusPathInDirection"},
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/components/events/ContainerEventHandler;children()Ljava/util/List;"
            )
    )
    default List<?> modifyFocusCandidates(ParentElement instance, @Local(argsOnly = true) NavigationDirection direction) {
        if (direction.getAxis() == NavigationAxis.HORIZONTAL)
            return instance.children().stream().filter(child -> !(child instanceof TabNavigationWidget)).toList();
        return instance.children();
    }
}
/*?} else {*/
/*@Mixin(ContainerEventHandler.class)
public class ContainerEventHandlerMixin {

}
*//*?}*/
