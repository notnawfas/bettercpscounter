package com.notnawfas.betterpvputils.config;

import com.notnawfas.betterpvputils.hud.HudPositionScreen;
import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.ColorControllerBuilder;
import dev.isxander.yacl3.api.controller.DoubleSliderControllerBuilder;
import dev.isxander.yacl3.api.controller.StringControllerBuilder;
import dev.isxander.yacl3.api.controller.TickBoxControllerBuilder;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_437;

public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return parentScreen -> buildConfigScreen(parentScreen);
    }

    private class_437 buildConfigScreen(class_437 parent) {
        ModConfig config = ModConfig.getConfig();

        return YetAnotherConfigLib.createBuilder()
                .title(class_2561.method_43471("betterpvputils.config.title"))
                .category(ConfigCategory.createBuilder()
                        .name(class_2561.method_43471("betterpvputils.config.category.cps"))
                        .option(Option.<Boolean>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.enabled"))
                                .description(OptionDescription.of(class_2561.method_43471("betterpvputils.config.option.enabled.description")))
                                .binding(true, () -> config.enabled, val -> config.enabled = val)
                                .controller(TickBoxControllerBuilder::create)
                                .build())
                        .option(Option.<String>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.displayFormat"))
                                .description(OptionDescription.of(class_2561.method_43471("betterpvputils.config.option.displayFormat.description")))
                                .binding("[LMB: %cps_mouse.left% | RMB: %cps_mouse.right%]", () -> config.displayFormat, val -> config.displayFormat = val)
                                .controller(StringControllerBuilder::create)
                                .build())
                        .option(Option.<Boolean>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.useMinecraftFont"))
                                .binding(true, () -> config.useMinecraftFont, val -> config.useMinecraftFont = val)
                                .controller(TickBoxControllerBuilder::create)
                                .build())
                        .option(Option.<Boolean>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.showBackground"))
                                .binding(true, () -> config.showBackground, val -> config.showBackground = val)
                                .controller(TickBoxControllerBuilder::create)
                                .build())
                        .option(Option.<Color>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.backgroundColor"))
                                .binding(new Color(0, 0, 0, 128), () -> new Color(config.backgroundColor, true), val -> config.backgroundColor = val.getRGB())
                                .controller(opt -> ColorControllerBuilder.create(opt).allowAlpha(true))
                                .build())
                        .option(Option.<Color>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.textColor"))
                                .binding(Color.WHITE, () -> new Color(config.textColor, true), val -> config.textColor = val.getRGB())
                                .controller(opt -> ColorControllerBuilder.create(opt).allowAlpha(true))
                                .build())
                        .build())
                .category(ConfigCategory.createBuilder()
                        .name(class_2561.method_43471("betterpvputils.config.category.position"))
                        .option(Option.<Double>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.posX"))
                                .binding(0.0, () -> config.posX, val -> config.posX = val)
                                .controller(opt -> DoubleSliderControllerBuilder.create(opt).range(0.0, 1.0).step(0.005))
                                .build())
                        .option(Option.<Double>createBuilder()
                                .name(class_2561.method_43471("betterpvputils.config.option.posY"))
                                .binding(0.0, () -> config.posY, val -> config.posY = val)
                                .controller(opt -> DoubleSliderControllerBuilder.create(opt).range(0.0, 1.0).step(0.005))
                                .build())
                        .build())
                .save(() -> ModConfig.getConfig().save())
                .build()
                .generateScreen(parent);
    }
}
