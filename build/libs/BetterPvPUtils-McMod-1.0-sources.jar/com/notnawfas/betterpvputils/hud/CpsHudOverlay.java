package com.notnawfas.betterpvputils.hud;

import com.notnawfas.betterpvputils.config.ModConfig;
import com.notnawfas.betterpvputils.cps.CpsVariable;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class CpsHudOverlay implements HudRenderCallback {

    private static final int PADDING = 2;

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        ModConfig config = ModConfig.getConfig();
        if (!config.enabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        String resolved = CpsVariable.resolve(config.displayFormat);
        class_2561 displayText = class_2561.method_43470(resolved);

        int textWidth = client.field_1772.method_1727(resolved);
        int textHeight = client.field_1772.field_2000;

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int x = (int) (config.posX * (screenWidth - textWidth - PADDING * 2));
        int y = (int) (config.posY * (screenHeight - textHeight - PADDING * 2));

        x = Math.max(0, Math.min(x, screenWidth - textWidth - PADDING * 2));
        y = Math.max(0, Math.min(y, screenHeight - textHeight - PADDING * 2));

        if (config.showBackground) {
            drawContext.method_25294(x, y, x + textWidth + PADDING * 2, y + textHeight + PADDING * 2, config.backgroundColor);
        }

        drawContext.method_51439(client.field_1772, displayText, x + PADDING, y + PADDING, config.textColor, true);
    }

    public static void renderPreview(class_332 drawContext, ModConfig config, int forcedX, int forcedY) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(config.displayFormat);
        class_2561 displayText = class_2561.method_43470(resolved);

        int textWidth = client.field_1772.method_1727(resolved);
        int textHeight = client.field_1772.field_2000;

        if (config.showBackground) {
            drawContext.method_25294(forcedX, forcedY, forcedX + textWidth + PADDING * 2, forcedY + textHeight + PADDING * 2, config.backgroundColor);
        }

        drawContext.method_51439(client.field_1772, displayText, forcedX + PADDING, forcedY + PADDING, config.textColor, true);
    }

    public static int getHudWidth(ModConfig config) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(config.displayFormat);
        return client.field_1772.method_1727(resolved) + PADDING * 2;
    }

    public static int getHudHeight() {
        return class_310.method_1551().field_1772.field_2000 + PADDING * 2;
    }
}
