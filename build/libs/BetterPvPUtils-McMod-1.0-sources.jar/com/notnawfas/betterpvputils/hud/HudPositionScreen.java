package com.notnawfas.betterpvputils.hud;

import com.notnawfas.betterpvputils.config.ModConfig;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class HudPositionScreen extends class_437 {

    private static final int PADDING = 2;

    private final class_437 parent;
    private boolean dragging = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;

    public HudPositionScreen(class_437 parent) {
        super(class_2561.method_43471("betterpvputils.screen.reposition.title"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(field_22789 / 2 - 50, field_22790 - 30, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        method_25420(drawContext, mouseX, mouseY, delta);

        ModConfig config = ModConfig.getConfig();

        int hudWidth = CpsHudOverlay.getHudWidth(config);
        int hudHeight = CpsHudOverlay.getHudHeight();

        int hudX = (int) (config.posX * (field_22789 - hudWidth));
        int hudY = (int) (config.posY * (field_22790 - hudHeight));

        hudX = Math.max(0, Math.min(hudX, field_22789 - hudWidth));
        hudY = Math.max(0, Math.min(hudY, field_22790 - hudHeight));

        CpsHudOverlay.renderPreview(drawContext, config, hudX, hudY);

        drawOutline(drawContext, hudX, hudY, hudWidth, hudHeight, 0xFFFFFFFF);

        drawContext.method_27534(field_22793, class_2561.method_43471("betterpvputils.screen.reposition.title"), field_22789 / 2, 10, 0xFFFFFF);

        super.method_25394(drawContext, mouseX, mouseY, delta);
    }

    private void drawOutline(class_332 drawContext, int x, int y, int w, int h, int color) {
        drawContext.method_25294(x, y, x + w, y + 1, color);
        drawContext.method_25294(x, y + h - 1, x + w, y + h, color);
        drawContext.method_25294(x, y, x + 1, y + h, color);
        drawContext.method_25294(x + w - 1, y, x + w, y + h, color);
    }

    @Override
    public boolean method_25402(class_11909 click, boolean always) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return super.method_25402(click, always);
        }

        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();

        ModConfig config = ModConfig.getConfig();

        int hudWidth = CpsHudOverlay.getHudWidth(config);
        int hudHeight = CpsHudOverlay.getHudHeight();

        int hudX = (int) (config.posX * (field_22789 - hudWidth));
        int hudY = (int) (config.posY * (field_22790 - hudHeight));

        hudX = Math.max(0, Math.min(hudX, field_22789 - hudWidth));
        hudY = Math.max(0, Math.min(hudY, field_22790 - hudHeight));

        if (mouseX >= hudX && mouseX <= hudX + hudWidth && mouseY >= hudY && mouseY <= hudY + hudHeight) {
            dragging = true;
            dragOffsetX = mouseX - hudX;
            dragOffsetY = mouseY - hudY;
            return true;
        }
        return super.method_25402(click, always);
    }

    @Override
    public boolean method_25403(class_11909 click, double dragX, double dragY) {
        if (dragging) {
            double mouseX = click.comp_4798();
            double mouseY = click.comp_4799();

            ModConfig config = ModConfig.getConfig();

            int hudWidth = CpsHudOverlay.getHudWidth(config);
            int hudHeight = CpsHudOverlay.getHudHeight();

            int newHudX = (int) (mouseX - dragOffsetX);
            int newHudY = (int) (mouseY - dragOffsetY);

            newHudX = Math.max(0, Math.min(newHudX, field_22789 - hudWidth));
            newHudY = Math.max(0, Math.min(newHudY, field_22790 - hudHeight));

            config.posX = (field_22789 - hudWidth) > 0 ? (double) newHudX / (field_22789 - hudWidth) : 0.0;
            config.posY = (field_22790 - hudHeight) > 0 ? (double) newHudY / (field_22790 - hudHeight) : 0.0;

            config.posX = Math.max(0.0, Math.min(1.0, config.posX));
            config.posY = Math.max(0.0, Math.min(1.0, config.posY));

            return true;
        }
        return super.method_25403(click, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (dragging) {
            dragging = false;
            ModConfig.getConfig().save();
            return true;
        }
        return super.method_25406(click);
    }

    @Override
    public void method_25419() {
        ModConfig.getConfig().save();
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
