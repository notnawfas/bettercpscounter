package com.notnawfas.ultimatepvputils;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import com.notnawfas.ultimatepvputils.config.ModConfigScreen;
import com.notnawfas.ultimatepvputils.hud.CpsHudOverlay;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class UltimatePvPUtilsClient implements ClientModInitializer {

    private static class_304 configKey;

    private static final class_304.class_11900 MOD_CATEGORY = class_304.class_11900.method_74698(class_2960.method_60655("ultimatepvputils", "keybindings"));

    private static boolean hasShownHint = false;

    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register(new CpsHudOverlay());

        configKey = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.ultimatepvputils.open_config",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_F7,
            MOD_CATEGORY
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (configKey.method_1436()) {
                client.method_1507(new ModConfigScreen(null));
            }
            if (!hasShownHint && client.field_1724 != null) {
                hasShownHint = true;
                client.field_1724.method_7353(class_2561.method_43470("§b[Ultimate PvP Utils]§7 Press §bF7§7 to open config"), false);
            }
        });
    }
}
