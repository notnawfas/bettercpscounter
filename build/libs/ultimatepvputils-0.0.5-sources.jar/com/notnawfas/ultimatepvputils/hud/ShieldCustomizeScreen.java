package com.notnawfas.ultimatepvputils.hud;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import com.notnawfas.ultimatepvputils.config.ShieldConfig;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class ShieldCustomizeScreen extends class_437 {

    private static final int PANEL_WIDTH = 220;
    private static final int PANEL_PADDING = 12;
    private static final int SLIDER_TRACK_H = 8;
    private static final int SLIDER_KNOB_W = 10;
    private static final int SLIDER_KNOB_H = 14;
    private static final int ROW_HEIGHT = 36;
    private static final int LABEL_H = 14;
    private static final int SECTION_GAP = 16;

    private final class_437 parent;

    private boolean sliderDragging = false;
    private int activeSlider = -1;
    private int sliderTrackX = 0;
    private int sliderTrackW = 0;

    public ShieldCustomizeScreen(class_437 parent) {
        super(class_2561.method_43470("Shield Customize"));
        this.parent = parent;
    }

    private ShieldConfig cfg() {
        return ModConfig.getConfig().shieldConfig;
    }

    @Override
    public void method_25394(class_332 dc, int mouseX, int mouseY, float delta) {
        method_25420(dc, mouseX, mouseY, delta);

        int panelX = field_22789 - PANEL_WIDTH;
        int panelY = 0;
        int panelH = field_22790;

        dc.method_25294(panelX, panelY, panelX + PANEL_WIDTH, panelH, DrawUtils.OVERLAY_BG);
        dc.method_25294(panelX, panelY, panelX + 1, panelH, DrawUtils.BORDER);

        int cx = panelX + PANEL_PADDING;
        int cy = panelY + PANEL_PADDING;
        int cw = PANEL_WIDTH - PANEL_PADDING * 2;

        dc.method_25303(field_22793, "Shield Transform", cx, cy, DrawUtils.ACCENT);
        cy += SECTION_GAP;

        cy = drawSliderRow(dc, "Size", cfg().size, ShieldConfig.MIN_SIZE, ShieldConfig.MAX_SIZE, "%.1fx", 0, cx, cy, cw, mouseX, mouseY);
        cy = drawSliderRow(dc, "Offset X", cfg().offsetX, ShieldConfig.MIN_OFFSET, ShieldConfig.MAX_OFFSET, "%.0f", 1, cx, cy, cw, mouseX, mouseY);
        cy = drawSliderRow(dc, "Offset Y", cfg().offsetY, ShieldConfig.MIN_OFFSET, ShieldConfig.MAX_OFFSET, "%.0f", 2, cx, cy, cw, mouseX, mouseY);

        cy += 4;
        drawCheckboxRow(dc, "Visible", cfg().visible, cx, cy, cw, mouseX, mouseY);
        cy += ROW_HEIGHT;

        cy += 8;
        int btnW = cw;
        int btnH = 22;
        boolean resetHovered = mouseX >= cx && mouseX < cx + btnW && mouseY >= cy && mouseY < cy + btnH;
        dc.method_25294(cx, cy, cx + btnW, cy + btnH, resetHovered ? DrawUtils.RESET_HOVER : DrawUtils.RESET_BG);
        DrawUtils.drawBorder(dc, cx, cy, btnW, btnH, DrawUtils.RESET_BORDER);
        dc.method_25300(field_22793, "Reset to Defaults", cx + btnW / 2, cy + 7, DrawUtils.RESET_TEXT);

        drawShieldPreview(dc, panelX);
        dc.method_25300(field_22793, "ESC to confirm", panelX / 2, field_22790 - 20, DrawUtils.ACCENT_DIM);
    }

    private void drawShieldPreview(class_332 dc, int panelX) {
        int previewW = panelX;
        int previewH = field_22790;

        dc.method_25294(0, previewH - 24, previewW, previewH, DrawUtils.OVERLAY_DARK);
        dc.method_25300(field_22793, "Shield preview updates live \u2014 hold a shield!", previewW / 2, previewH - 18, DrawUtils.TEXT_DIM);
    }

    private int drawSliderRow(class_332 dc, String label, double value, double min, double max, String fmt, int id, int x, int y, int w, int mx, int my) {
        String displayVal = String.format(fmt, value);
        dc.method_25303(field_22793, label, x, y, DrawUtils.TEXT_LABEL);
        int valW = field_22793.method_1727(displayVal);
        dc.method_25303(field_22793, displayVal, x + w - valW, y, DrawUtils.TEXT_PRIMARY);
        y += LABEL_H;

        drawSlider(dc, value, min, max, x, y, w, mx, my, id);

        y += SLIDER_KNOB_H + 8;
        return y;
    }

    private void drawSlider(class_332 dc, double value, double min, double max, int x, int y, int w, int mx, int my, int id) {
        int trackY = y + (SLIDER_KNOB_H - SLIDER_TRACK_H) / 2;
        dc.method_25294(x, trackY, x + w, trackY + SLIDER_TRACK_H, DrawUtils.BORDER_LIGHT);

        double ratio = (max > min) ? (value - min) / (max - min) : 0;
        int filledW = (int) (w * ratio);
        dc.method_25294(x, trackY, x + filledW, trackY + SLIDER_TRACK_H, DrawUtils.ACCENT);

        int knobX = x + filledW - SLIDER_KNOB_W / 2;
        knobX = Math.max(x, Math.min(knobX, x + w - SLIDER_KNOB_W));

        boolean active = sliderDragging && activeSlider == id;
        boolean hovered = mx >= knobX && mx < knobX + SLIDER_KNOB_W && my >= y && my < y + SLIDER_KNOB_H;
        int knobColor = (active || hovered) ? DrawUtils.KNOB : DrawUtils.KNOB_ALT;
        dc.method_25294(knobX, y, knobX + SLIDER_KNOB_W, y + SLIDER_KNOB_H, knobColor);
        DrawUtils.drawBorder(dc, knobX, y, SLIDER_KNOB_W, SLIDER_KNOB_H, DrawUtils.BORDER_DIM);
    }

    private void drawCheckboxRow(class_332 dc, String label, boolean value, int x, int y, int w, int mx, int my) {
        dc.method_25303(field_22793, label, x, y + 1, DrawUtils.TEXT_LABEL);
        int boxSize = 18;
        int boxX = x + w - boxSize;
        boolean hovered = mx >= boxX && mx < boxX + boxSize && my >= y && my < y + boxSize;
        dc.method_25294(boxX, y, boxX + boxSize, y + boxSize, hovered ? DrawUtils.BTN_HOVER : DrawUtils.BTN_BG);
        DrawUtils.drawBorder(dc, boxX, y, boxSize, boxSize, value ? DrawUtils.ACCENT : DrawUtils.BORDER);
        if (value) {
            dc.method_25303(field_22793, "\u2713", boxX + 5, y + 4, DrawUtils.ACCENT);
        }
    }

    @Override
    public void method_25420(class_332 dc, int mouseX, int mouseY, float delta) {
        if (this.field_22787 != null && this.field_22787.field_1687 != null) {
            this.field_22787.field_1773.method_3188(this.field_22787.method_61966());
        } else {
            dc.method_25294(0, 0, field_22789, field_22790, DrawUtils.CARD_BG);
        }
    }

    private int[] getSliderHitArea(int id) {
        int panelX = field_22789 - PANEL_WIDTH;
        int cx = panelX + PANEL_PADDING;
        int cw = PANEL_WIDTH - PANEL_PADDING * 2;
        int cy = PANEL_PADDING + SECTION_GAP;

        for (int i = 0; i < id; i++) {
            cy += ROW_HEIGHT;
        }
        int sliderY = cy + LABEL_H;
        return new int[]{cx, sliderY, cw, SLIDER_KNOB_H};
    }

    @Override
    public boolean method_25402(class_11909 click, boolean always) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) return super.method_25402(click, always);
        int mx = (int) click.comp_4798(), my = (int) click.comp_4799();

        for (int id = 0; id < 3; id++) {
            int[] area = getSliderHitArea(id);
            if (mx >= area[0] && mx < area[0] + area[2] && my >= area[1] - 2 && my < area[1] + area[3] + 2) {
                sliderDragging = true;
                activeSlider = id;
                sliderTrackX = area[0];
                sliderTrackW = area[2];
                double ratio = Math.max(0, Math.min(1, (double) (mx - sliderTrackX) / sliderTrackW));
                setSliderValue(id, ratio);
                ModConfig.getConfig().requestSave();
                return true;
            }
        }

        int panelX = field_22789 - PANEL_WIDTH;
        int cx = panelX + PANEL_PADDING;
        int cw = PANEL_WIDTH - PANEL_PADDING * 2;
        int checkboxY = PANEL_PADDING + SECTION_GAP + ROW_HEIGHT * 3 + 4;
        int boxSize = 18;
        int boxX = cx + cw - boxSize;
        if (mx >= boxX && mx < boxX + boxSize && my >= checkboxY && my < checkboxY + boxSize) {
            cfg().visible = !cfg().visible;
            ModConfig.getConfig().requestSave();
            return true;
        }

        int cy = checkboxY + ROW_HEIGHT + 8;
        int btnW = cw;
        int btnH = 22;
        if (mx >= cx && mx < cx + btnW && my >= cy && my < cy + btnH) {
            cfg().resetToDefaults();
            ModConfig.getConfig().requestSave();
            return true;
        }

        return super.method_25402(click, always);
    }

    @Override
    public boolean method_25403(class_11909 click, double dragX, double dragY) {
        if (sliderDragging && activeSlider >= 0) {
            int mx = (int) click.comp_4798();
            double ratio = Math.max(0, Math.min(1, (double) (mx - sliderTrackX) / sliderTrackW));
            setSliderValue(activeSlider, ratio);
            return true;
        }
        return super.method_25403(click, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (sliderDragging) {
            sliderDragging = false;
            activeSlider = -1;
            ModConfig.getConfig().requestSave();
            return true;
        }
        return super.method_25406(click);
    }

    private double getSliderValue(int id) {
        return switch (id) {
            case 0 -> cfg().size;
            case 1 -> cfg().offsetX;
            case 2 -> cfg().offsetY;
            default -> 0;
        };
    }

    private void setSliderValue(int id, double ratio) {
        ratio = Math.max(0, Math.min(1, ratio));
        switch (id) {
            case 0 -> {
                double range = ShieldConfig.MAX_SIZE - ShieldConfig.MIN_SIZE;
                cfg().size = Math.round((ShieldConfig.MIN_SIZE + ratio * range) * 10.0) / 10.0;
            }
            case 1 -> {
                double range = ShieldConfig.MAX_OFFSET - ShieldConfig.MIN_OFFSET;
                cfg().offsetX = Math.round(ShieldConfig.MIN_OFFSET + ratio * range);
            }
            case 2 -> {
                double range = ShieldConfig.MAX_OFFSET - ShieldConfig.MIN_OFFSET;
                cfg().offsetY = Math.round(ShieldConfig.MIN_OFFSET + ratio * range);
            }
        }
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        return true;
    }

    @Override
    public void method_25419() {
        ModConfig.getConfig().save();
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() { return false; }
}
