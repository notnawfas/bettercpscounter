package com.notnawfas.ultimatepvputils.mixin;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import com.notnawfas.ultimatepvputils.config.ShieldConfig;
import com.notnawfas.ultimatepvputils.hud.ShieldCustomizeScreen;
import net.minecraft.class_11659;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1819;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_759;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_759.class)
public class HeldItemRendererMixin {

    @Inject(
        method = "renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ItemDisplayContext;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/client/render/item/ItemRenderState;render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;III)V"
        )
    )
    private void onBeforeItemRender(
        class_1309 entity, class_1799 stack, class_811 renderMode,
        class_4587 matrices, class_11659 queue, int light,
        CallbackInfo ci
    ) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1819)) return;
        if (!renderMode.method_29998()) return;

        ShieldConfig cfg = ModConfig.getConfig().shieldConfig;
        class_310 client = class_310.method_1551();
        boolean onCustomize = client.field_1755 instanceof ShieldCustomizeScreen;

        if (!cfg.visible && !onCustomize) {
            matrices.method_22905(0, 0, 0);
            return;
        }

        matrices.method_46416((float) cfg.offsetX / 100F, (float) -cfg.offsetY / 100F, 0);
        float scale = (float) cfg.size;
        matrices.method_22905(scale, scale, scale);
    }
}
