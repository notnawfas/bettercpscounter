package com.notnawfas.ultimatepvputils.hud;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import com.notnawfas.ultimatepvputils.config.CounterEntry;
import com.notnawfas.ultimatepvputils.cps.CpsVariable;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import java.util.List;

public class CpsHudOverlay implements HudRenderCallback {

    private static final int INNER_PADDING = 4;
    private static final int BORDER_WIDTH = 1;
    private static final int SNAP_THRESHOLD = 6;

    private static boolean snappingActive = false;

    public static void setSnappingActive(boolean active) {
        snappingActive = active;
    }

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        ModConfig config = ModConfig.getConfig();
        if (!config.enabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        List<CounterEntry> counters = config.counters;
        if (counters.isEmpty()) return;

        int screenW = client.method_22683().method_4486();
        int screenH = client.method_22683().method_4502();

        int count = counters.size();
        String[] resolvedTexts = new String[count];
        int[] xs = new int[count];
        int[] ys = new int[count];
        int[] ws = new int[count];
        int[] hs = new int[count];

        for (int i = 0; i < count; i++) {
            CounterEntry entry = counters.get(i);
            String resolved = CpsVariable.resolve(entry.displayFormat);
            resolvedTexts[i] = resolved;
            float scale = (float) Math.max(0.5, Math.min(2.0, entry.scale));
            int textWidth = client.field_1772.method_1727(resolved);
            int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
            int totalHeight = client.field_1772.field_2000 + (INNER_PADDING + BORDER_WIDTH) * 2;
            int scaledWidth = (int) (totalWidth * scale);
            int scaledHeight = (int) (totalHeight * scale);

            ws[i] = scaledWidth;
            hs[i] = scaledHeight;
            xs[i] = Math.max(0, Math.min((int) (entry.posX * (screenW - scaledWidth)), screenW - scaledWidth));
            ys[i] = Math.max(0, Math.min((int) (entry.posY * (screenH - scaledHeight)), screenH - scaledHeight));
        }

        if (snappingActive) {
            for (int pass = 0; pass < 3; pass++) {
                for (int i = 0; i < count; i++) {
                    int bestDx = xs[i], bestDy = ys[i];
                    double bestDistX = SNAP_THRESHOLD + 1, bestDistY = SNAP_THRESHOLD + 1;

                    for (int j = 0; j < count; j++) {
                        if (i == j) continue;
                        int[] snapResult = findClosestSnap(xs[i], ys[i], ws[i], hs[i], xs[j], ys[j], ws[j], hs[j]);
                        if (snapResult[2] < bestDistX) { bestDistX = snapResult[2]; bestDx = snapResult[0]; }
                        if (snapResult[3] < bestDistY) { bestDistY = snapResult[3]; bestDy = snapResult[1]; }
                    }

                    if (Math.abs(xs[i]) < SNAP_THRESHOLD && SNAP_THRESHOLD < bestDistX) bestDx = 0;
                    if (Math.abs(xs[i] + ws[i] - screenW) < SNAP_THRESHOLD && SNAP_THRESHOLD < bestDistX) bestDx = screenW - ws[i];
                    if (Math.abs(ys[i]) < SNAP_THRESHOLD && SNAP_THRESHOLD < bestDistY) bestDy = 0;
                    if (Math.abs(ys[i] + hs[i] - screenH) < SNAP_THRESHOLD && SNAP_THRESHOLD < bestDistY) bestDy = screenH - hs[i];

                    xs[i] = Math.max(0, Math.min(bestDx, screenW - ws[i]));
                    ys[i] = Math.max(0, Math.min(bestDy, screenH - hs[i]));
                }
            }
        }

        for (int i = 0; i < count; i++) {
            CounterEntry entry = counters.get(i);
            String resolved = resolvedTexts[i];
            class_2561 displayText = class_2561.method_43470(resolved);
            float scale = (float) Math.max(0.5, Math.min(2.0, entry.scale));
            int textWidth = client.field_1772.method_1727(resolved);
            int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
            int totalHeight = client.field_1772.field_2000 + (INNER_PADDING + BORDER_WIDTH) * 2;

            drawContext.method_51448().pushMatrix();
            try {
                drawContext.method_51448().translate(xs[i], ys[i]);
                drawContext.method_51448().scale(scale, scale);

                if (entry.showBackground) {
                    int borderColor = deriveBorderColor(entry.backgroundColor);
                    drawContext.method_25294(0, 0, totalWidth, totalHeight, borderColor);
                    drawContext.method_25294(BORDER_WIDTH, BORDER_WIDTH, totalWidth - BORDER_WIDTH, totalHeight - BORDER_WIDTH, entry.backgroundColor);
                }

                drawContext.method_51439(client.field_1772, displayText, INNER_PADDING + BORDER_WIDTH, INNER_PADDING + BORDER_WIDTH, entry.textColor, true);
            } finally {
                drawContext.method_51448().popMatrix();
            }
        }
    }

    private static int[] findClosestSnap(int ax, int ay, int aw, int ah, int bx, int by, int bw, int bh) {
        int bestX = ax, bestY = ay;
        double bestDistX = SNAP_THRESHOLD + 1, bestDistY = SNAP_THRESHOLD + 1;

        int[][] xSnaps = {
                {bx, Math.abs(ax - bx)},
                {bx + bw, Math.abs(ax - bx - bw)},
                {bx + bw - aw, Math.abs(ax + aw - bx - bw)},
                {bx - aw, Math.abs(ax - bx + aw)}
        };
        for (int[] snap : xSnaps) {
            if (snap[1] < bestDistX) { bestDistX = snap[1]; bestX = snap[0]; }
        }

        int[][] ySnaps = {
                {by, Math.abs(ay - by)},
                {by + bh, Math.abs(ay - by - bh)},
                {by + bh - ah, Math.abs(ay + ah - by - bh)},
                {by - ah, Math.abs(ay - by + ah)}
        };
        for (int[] snap : ySnaps) {
            if (snap[1] < bestDistY) { bestDistY = snap[1]; bestY = snap[0]; }
        }

        return new int[]{bestX, bestY, (int) bestDistX, (int) bestDistY};
    }

    public static void renderPreview(class_332 drawContext, CounterEntry entry, int forcedX, int forcedY) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(entry.displayFormat);
        class_2561 displayText = class_2561.method_43470(resolved);
        float scale = (float) Math.max(0.5, Math.min(2.0, entry.scale));
        int textWidth = client.field_1772.method_1727(resolved);
        int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
        int totalHeight = client.field_1772.field_2000 + (INNER_PADDING + BORDER_WIDTH) * 2;

        drawContext.method_51448().pushMatrix();
        try {
            drawContext.method_51448().translate(forcedX, forcedY);
            drawContext.method_51448().scale(scale, scale);

            if (entry.showBackground) {
                int borderColor = deriveBorderColor(entry.backgroundColor);
                drawContext.method_25294(0, 0, totalWidth, totalHeight, borderColor);
                drawContext.method_25294(BORDER_WIDTH, BORDER_WIDTH, totalWidth - BORDER_WIDTH, totalHeight - BORDER_WIDTH, entry.backgroundColor);
            }

            drawContext.method_51439(client.field_1772, displayText, INNER_PADDING + BORDER_WIDTH, INNER_PADDING + BORDER_WIDTH, entry.textColor, true);
        } finally {
            drawContext.method_51448().popMatrix();
        }
    }

    public static int getHudWidth(CounterEntry entry) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(entry.displayFormat);
        float scale = (float) Math.max(0.5, Math.min(2.0, entry.scale));
        int textWidth = client.field_1772.method_1727(resolved);
        return (int) ((textWidth + (INNER_PADDING + BORDER_WIDTH) * 2) * scale);
    }

    public static int getHudHeight(CounterEntry entry) {
        float scale = (float) Math.max(0.5, Math.min(2.0, entry.scale));
        int textHeight = class_310.method_1551().field_1772.field_2000;
        return (int) ((textHeight + (INNER_PADDING + BORDER_WIDTH) * 2) * scale);
    }

    private static int deriveBorderColor(int bgColor) {
        int srcA = (bgColor >> 24) & 0xFF;
        if (srcA == 0) return 0;
        int a = Math.min(255, srcA + 40);
        int r = Math.min(255, ((bgColor >> 16) & 0xFF) + 30);
        int g = Math.min(255, ((bgColor >> 8) & 0xFF) + 30);
        int b = Math.min(255, (bgColor & 0xFF) + 30);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
