package com.notnawfas.ultimatepvputils.hud;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import com.notnawfas.ultimatepvputils.cps.CpsVariable;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class CpsHudOverlay implements HudRenderCallback {

    private static final int INNER_PADDING = 4;
    private static final int BORDER_WIDTH = 1;

    @Override
    public void onHudRender(class_332 drawContext, class_9779 tickCounter) {
        ModConfig config = ModConfig.getConfig();
        if (!config.enabled) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        String resolved = CpsVariable.resolve(config.displayFormat);
        class_2561 displayText = class_2561.method_43470(resolved);

        float scale = (float) Math.max(0.5, Math.min(2.0, config.scale));
        int textWidth = client.field_1772.method_1727(resolved);
        int textHeight = client.field_1772.field_2000;

        int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
        int totalHeight = textHeight + (INNER_PADDING + BORDER_WIDTH) * 2;

        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int scaledWidth = (int) (totalWidth * scale);
        int scaledHeight = (int) (totalHeight * scale);

        int x = (int) (config.posX * (screenWidth - scaledWidth));
        int y = (int) (config.posY * (screenHeight - scaledHeight));

        x = Math.max(0, Math.min(x, screenWidth - scaledWidth));
        y = Math.max(0, Math.min(y, screenHeight - scaledHeight));

        drawContext.method_51448().pushMatrix();
        drawContext.method_51448().translate(x, y);
        drawContext.method_51448().scale(scale, scale);

        if (config.showBackground) {
            int borderColor = deriveBorderColor(config.backgroundColor);
            drawContext.method_25294(0, 0, totalWidth, totalHeight, borderColor);
            drawContext.method_25294(BORDER_WIDTH, BORDER_WIDTH,
                totalWidth - BORDER_WIDTH, totalHeight - BORDER_WIDTH,
                config.backgroundColor);
        }

        drawContext.method_51439(client.field_1772, displayText,
            INNER_PADDING + BORDER_WIDTH,
            INNER_PADDING + BORDER_WIDTH,
            config.textColor, true);

        drawContext.method_51448().popMatrix();
    }

    public static void renderPreview(class_332 drawContext, ModConfig config, int forcedX, int forcedY) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(config.displayFormat);
        class_2561 displayText = class_2561.method_43470(resolved);

        float scale = (float) Math.max(0.5, Math.min(2.0, config.scale));
        int textWidth = client.field_1772.method_1727(resolved);
        int textHeight = client.field_1772.field_2000;

        int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
        int totalHeight = textHeight + (INNER_PADDING + BORDER_WIDTH) * 2;

        drawContext.method_51448().pushMatrix();
        drawContext.method_51448().translate(forcedX, forcedY);
        drawContext.method_51448().scale(scale, scale);

        if (config.showBackground) {
            int borderColor = deriveBorderColor(config.backgroundColor);
            drawContext.method_25294(0, 0, totalWidth, totalHeight, borderColor);
            drawContext.method_25294(BORDER_WIDTH, BORDER_WIDTH,
                totalWidth - BORDER_WIDTH, totalHeight - BORDER_WIDTH,
                config.backgroundColor);
        }

        drawContext.method_51439(client.field_1772, displayText,
            INNER_PADDING + BORDER_WIDTH,
            INNER_PADDING + BORDER_WIDTH,
            config.textColor, true);

        drawContext.method_51448().popMatrix();
    }

    public static int getHudWidth(ModConfig config) {
        class_310 client = class_310.method_1551();
        String resolved = CpsVariable.resolve(config.displayFormat);
        float scale = (float) Math.max(0.5, Math.min(2.0, config.scale));
        int textWidth = client.field_1772.method_1727(resolved);
        int totalWidth = textWidth + (INNER_PADDING + BORDER_WIDTH) * 2;
        return (int) (totalWidth * scale);
    }

    public static int getHudHeight() {
        float scale = (float) Math.max(0.5, Math.min(2.0, ModConfig.getConfig().scale));
        int textHeight = class_310.method_1551().field_1772.field_2000;
        int totalHeight = textHeight + (INNER_PADDING + BORDER_WIDTH) * 2;
        return (int) (totalHeight * scale);
    }

    private static int deriveBorderColor(int bgColor) {
        int a = Math.min(255, ((bgColor >> 24) & 0xFF) + 40);
        int r = Math.min(255, ((bgColor >> 16) & 0xFF) + 30);
        int g = Math.min(255, ((bgColor >> 8) & 0xFF) + 30);
        int b = Math.min(255, (bgColor & 0xFF) + 30);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
