package com.notnawfas.ultimatepvputils.hud;

import com.notnawfas.ultimatepvputils.config.ModConfig;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class HudPositionScreen extends class_437 {

    private final class_437 parent;
    private boolean dragging = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;

    private static final String[][] PRESET_LABELS = {
            {"Top-Left", "Top-Center", "Top-Right"},
            {"Mid-Left", "Center", "Mid-Right"},
            {"Bottom-Left", "Bottom-Center", "Bottom-Right"}
    };
    private static final double[][] PRESET_X = {
            {0.0, 0.5, 1.0},
            {0.0, 0.5, 1.0},
            {0.0, 0.5, 1.0}
    };
    private static final double[][] PRESET_Y = {
            {0.0, 0.0, 0.0},
            {0.5, 0.5, 0.5},
            {1.0, 1.0, 1.0}
    };

    private int selectedPresetRow = -1;
    private int selectedPresetCol = -1;

    public HudPositionScreen(class_437 parent) {
        super(class_2561.method_43471("ultimatepvputils.screen.reposition.title"));
        this.parent = parent;
        detectSelectedPreset();
    }

    private void detectSelectedPreset() {
        ModConfig config = ModConfig.getConfig();
        selectedPresetRow = -1;
        selectedPresetCol = -1;
        for (int r = 0; r < 3; r++) {
            for (int c = 0; c < 3; c++) {
                if (Math.abs(config.posX - PRESET_X[r][c]) < 0.01 && Math.abs(config.posY - PRESET_Y[r][c]) < 0.01) {
                    selectedPresetRow = r;
                    selectedPresetCol = c;
                    return;
                }
            }
        }
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        if (this.field_22787 != null && this.field_22787.field_1687 != null) {
            this.field_22787.field_1773.method_3188(this.field_22787.method_61966());
        }

        ModConfig config = ModConfig.getConfig();

        int hudWidth = CpsHudOverlay.getHudWidth(config);
        int hudHeight = CpsHudOverlay.getHudHeight();

        int hudX = (int) (config.posX * (field_22789 - hudWidth));
        int hudY = (int) (config.posY * (field_22790 - hudHeight));
        hudX = Math.max(0, Math.min(hudX, field_22789 - hudWidth));
        hudY = Math.max(0, Math.min(hudY, field_22790 - hudHeight));

        CpsHudOverlay.renderPreview(drawContext, config, hudX, hudY);

        long time = System.currentTimeMillis();
        float dashPhase = (time % 2000) / 2000.0f;
        drawAnimatedBorder(drawContext, hudX - 2, hudY - 2, hudWidth + 4, hudHeight + 4, 0xFFFFFFFF, dashPhase);

        int barH = 90;
        int barY = field_22790 - barH;
        drawContext.method_25294(0, barY, field_22789, field_22790, 0xB0000000);
        drawContext.method_25294(0, barY, field_22789, barY + 1, 0x40FFFFFF);

        drawContext.method_27534(field_22793, class_2561.method_43471("ultimatepvputils.screen.reposition.title"), field_22789 / 2, barY + 4, 0xFFFFFF);
        drawContext.method_25300(field_22793, "ESC to confirm", field_22789 / 2, barY + 16, 0xFFAAAAAA);

        int cellW = 80;
        int cellH = 28;
        int gridW = cellW * 3 + 8;
        int gridStartX = (field_22789 - gridW) / 2;
        int gridStartY = barY + 32;

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                int cx = gridStartX + col * (cellW + 4);
                int cy = gridStartY + row * (cellH + 2);
                boolean hovered = mouseX >= cx && mouseX < cx + cellW && mouseY >= cy && mouseY < cy + cellH;
                boolean selected = (row == selectedPresetRow && col == selectedPresetCol);

                int bg;
                if (selected) {
                    bg = 0x804FC3F7;
                } else if (hovered) {
                    bg = 0x40FFFFFF;
                } else {
                    bg = 0x30000000;
                }
                drawContext.method_25294(cx, cy, cx + cellW, cy + cellH, bg);

                int borderCol = selected ? 0xFF4FC3F7 : 0x60FFFFFF;
                drawContext.method_25294(cx, cy, cx + cellW, cy + 1, borderCol);
                drawContext.method_25294(cx, cy + cellH - 1, cx + cellW, cy + cellH, borderCol);
                drawContext.method_25294(cx, cy, cx + 1, cy + cellH, borderCol);
                drawContext.method_25294(cx + cellW - 1, cy, cx + cellW, cy + cellH, borderCol);

                int textCol = selected ? 0xFF4FC3F7 : 0xFFCCCCCC;
                drawContext.method_25300(field_22793, PRESET_LABELS[row][col], cx + cellW / 2, cy + cellH / 2 - 4, textCol);
            }
        }
    }

    private void drawAnimatedBorder(class_332 drawContext, int x, int y, int w, int h, int color, float phase) {
        int dashLen = 6;
        int gapLen = 4;
        int period = dashLen + gapLen;
        int offset = (int) (phase * period * 4);

        drawDashedLineH(drawContext, x, y, w, color, dashLen, gapLen, offset);
        drawDashedLineH(drawContext, x, y + h - 1, w, color, dashLen, gapLen, offset);
        drawDashedLineV(drawContext, x, y, h, color, dashLen, gapLen, offset);
        drawDashedLineV(drawContext, x + w - 1, y, h, color, dashLen, gapLen, offset);
    }

    private void drawDashedLineH(class_332 drawContext, int x, int y, int w, int color, int dashLen, int gapLen, int offset) {
        int period = dashLen + gapLen;
        int pos = -offset % period;
        if (pos < 0) pos += period;
        while (pos < w) {
            int startX = x + pos;
            int endX = Math.min(x + pos + dashLen, x + w);
            if (startX < x + w) {
                drawContext.method_25294(startX, y, endX, y + 1, color);
            }
            pos += period;
        }
    }

    private void drawDashedLineV(class_332 drawContext, int x, int y, int h, int color, int dashLen, int gapLen, int offset) {
        int period = dashLen + gapLen;
        int pos = -offset % period;
        if (pos < 0) pos += period;
        while (pos < h) {
            int startY = y + pos;
            int endY = Math.min(y + pos + dashLen, y + h);
            if (startY < y + h) {
                drawContext.method_25294(x, startY, x + 1, endY, color);
            }
            pos += period;
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean always) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            return super.method_25402(click, always);
        }

        double mouseX = click.comp_4798();
        double mouseY = click.comp_4799();

        int barH = 90;
        int barY = field_22790 - barH;

        int cellW = 80;
        int cellH = 28;
        int gridW = cellW * 3 + 8;
        int gridStartX = (field_22789 - gridW) / 2;
        int gridStartY = barY + 32;

        if (mouseY >= gridStartY) {
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 3; col++) {
                    int cx = gridStartX + col * (cellW + 4);
                    int cy = gridStartY + row * (cellH + 2);
                    if (mouseX >= cx && mouseX < cx + cellW && mouseY >= cy && mouseY < cy + cellH) {
                        ModConfig config = ModConfig.getConfig();
                        config.posX = PRESET_X[row][col];
                        config.posY = PRESET_Y[row][col];
                        config.save();
                        selectedPresetRow = row;
                        selectedPresetCol = col;
                        return true;
                    }
                }
            }
        }

        ModConfig config = ModConfig.getConfig();
        int hudWidth = CpsHudOverlay.getHudWidth(config);
        int hudHeight = CpsHudOverlay.getHudHeight();
        int hudX = (int) (config.posX * (field_22789 - hudWidth));
        int hudY = (int) (config.posY * (field_22790 - hudHeight));
        hudX = Math.max(0, Math.min(hudX, field_22789 - hudWidth));
        hudY = Math.max(0, Math.min(hudY, field_22790 - hudHeight));

        if (mouseX >= hudX - 2 && mouseX <= hudX + hudWidth + 2 && mouseY >= hudY - 2 && mouseY <= hudY + hudHeight + 2) {
            dragging = true;
            dragOffsetX = mouseX - hudX;
            dragOffsetY = mouseY - hudY;
            selectedPresetRow = -1;
            selectedPresetCol = -1;
            return true;
        }

        return super.method_25402(click, always);
    }

    @Override
    public boolean method_25403(class_11909 click, double dragX, double dragY) {
        if (dragging) {
            double mouseX = click.comp_4798();
            double mouseY = click.comp_4799();

            ModConfig config = ModConfig.getConfig();
            int hudWidth = CpsHudOverlay.getHudWidth(config);
            int hudHeight = CpsHudOverlay.getHudHeight();

            int newHudX = (int) (mouseX - dragOffsetX);
            int newHudY = (int) (mouseY - dragOffsetY);

            newHudX = Math.max(0, Math.min(newHudX, field_22789 - hudWidth));
            newHudY = Math.max(0, Math.min(newHudY, field_22790 - hudHeight));

            config.posX = (field_22789 - hudWidth) > 0 ? (double) newHudX / (field_22789 - hudWidth) : 0.0;
            config.posY = (field_22790 - hudHeight) > 0 ? (double) newHudY / (field_22790 - hudHeight) : 0.0;

            config.posX = Math.max(0.0, Math.min(1.0, config.posX));
            config.posY = Math.max(0.0, Math.min(1.0, config.posY));

            detectSelectedPreset();
            return true;
        }
        return super.method_25403(click, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (dragging) {
            dragging = false;
            ModConfig.getConfig().save();
            detectSelectedPreset();
            return true;
        }
        return super.method_25406(click);
    }

    @Override
    public void method_25419() {
        ModConfig.getConfig().save();
        if (field_22787 != null) {
            field_22787.method_1507(parent);
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
