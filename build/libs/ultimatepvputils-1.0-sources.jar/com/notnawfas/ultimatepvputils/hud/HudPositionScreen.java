package com.notnawfas.ultimatepvputils.hud;

import com.notnawfas.ultimatepvputils.config.CounterEntry;
import com.notnawfas.ultimatepvputils.config.ModConfig;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.lwjgl.glfw.GLFW;

public class HudPositionScreen extends class_437 {

    private final class_437 parent;
    private final CounterEntry counter;

    private boolean dragging = false;
    private double dragOffsetX = 0;
    private double dragOffsetY = 0;

    private boolean resizing = false;
    private double resizeAnchorX = 0;
    private double resizeAnchorY = 0;
    private double resizeStartScale = 1.0;

    private static final int EDGE_ZONE = 8;

    public HudPositionScreen(class_437 parent, CounterEntry counter) {
        super(class_2561.method_43470("Position"));
        this.parent = parent;
        this.counter = counter;
    }

    @Override
    public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
        if (this.field_22787 != null && this.field_22787.field_1687 != null) {
            this.field_22787.field_1773.method_3188(this.field_22787.method_61966());
        }

        if (counter == null) {
            drawContext.method_25300(field_22793, "ESC to confirm", field_22789 / 2, field_22790 / 2, 0xFFFFFF);
            return;
        }

        int hudWidth = CpsHudOverlay.getHudWidth(counter);
        int hudHeight = CpsHudOverlay.getHudHeight(counter);

        int hudX = (int) (counter.posX * (field_22789 - hudWidth));
        int hudY = (int) (counter.posY * (field_22790 - hudHeight));
        hudX = Math.max(0, Math.min(hudX, field_22789 - hudWidth));
        hudY = Math.max(0, Math.min(hudY, field_22790 - hudHeight));

        CpsHudOverlay.renderPreview(drawContext, counter, hudX, hudY);

        long time = System.currentTimeMillis();
        float dashPhase = (time % 2000) / 2000.0f;
        drawAnimatedBorder(drawContext, hudX - 2, hudY - 2, hudWidth + 4, hudHeight + 4, 0xFFFFFFFF, dashPhase);

        boolean onRightEdge = mouseX >= hudX + hudWidth - EDGE_ZONE && mouseX <= hudX + hudWidth + 2;
        boolean onBottomEdge = mouseY >= hudY + hudHeight - EDGE_ZONE && mouseY <= hudY + hudHeight + 2;
        boolean onCorner = onRightEdge && onBottomEdge;

        if (onCorner) {
            drawContext.method_25294(hudX + hudWidth - 8, hudY + hudHeight, hudX + hudWidth, hudY + hudHeight + 2, 0xFF4FC3F7);
            drawContext.method_25294(hudX + hudWidth, hudY + hudHeight - 8, hudX + hudWidth + 2, hudY + hudHeight, 0xFF4FC3F7);
        } else if (onRightEdge || onBottomEdge) {
            drawContext.method_25294(hudX + hudWidth - EDGE_ZONE, hudY + hudHeight, hudX + hudWidth + 2, hudY + hudHeight + 2, 0xFF4FC3F7);
            drawContext.method_25294(hudX + hudWidth, hudY + hudHeight - EDGE_ZONE, hudX + hudWidth + 2, hudY + hudHeight + 2, 0xFF4FC3F7);
        }

        drawContext.method_25300(field_22793, "ESC to confirm", field_22789 / 2, field_22790 / 2, 0xFFFFFF);
    }

    @Override
    public void method_49589() {
        CpsHudOverlay.setSnappingActive(true);
    }

    private void drawAnimatedBorder(class_332 dc, int x, int y, int w, int h, int color, float phase) {
        int dashLen = 6, gapLen = 4, period = dashLen + gapLen;
        int offset = (int) (phase * period * 4);
        drawDashedLineH(dc, x, y, w, color, dashLen, gapLen, offset);
        drawDashedLineH(dc, x, y + h - 1, w, color, dashLen, gapLen, offset);
        drawDashedLineV(dc, x, y, h, color, dashLen, gapLen, offset);
        drawDashedLineV(dc, x + w - 1, y, h, color, dashLen, gapLen, offset);
    }

    private void drawDashedLineH(class_332 dc, int x, int y, int w, int color, int dashLen, int gapLen, int offset) {
        int period = dashLen + gapLen;
        int pos = -offset % period;
        if (pos < 0) pos += period;
        while (pos < w) {
            int startX = x + pos;
            int endX = Math.min(x + pos + dashLen, x + w);
            if (startX < x + w) dc.method_25294(startX, y, endX, y + 1, color);
            pos += period;
        }
    }

    private void drawDashedLineV(class_332 dc, int x, int y, int h, int color, int dashLen, int gapLen, int offset) {
        int period = dashLen + gapLen;
        int pos = -offset % period;
        if (pos < 0) pos += period;
        while (pos < h) {
            int startY = y + pos;
            int endY = Math.min(y + pos + dashLen, y + h);
            if (startY < y + h) dc.method_25294(x, startY, x + 1, endY, color);
            pos += period;
        }
    }

    @Override
    public boolean method_25402(class_11909 click, boolean always) {
        if (click.method_74245() != GLFW.GLFW_MOUSE_BUTTON_LEFT) return super.method_25402(click, always);
        if (counter == null) return true;

        double mx = click.comp_4798(), my = click.comp_4799();
        int hudWidth = CpsHudOverlay.getHudWidth(counter);
        int hudHeight = CpsHudOverlay.getHudHeight(counter);
        int hudX = Math.max(0, Math.min((int) (counter.posX * (field_22789 - hudWidth)), field_22789 - hudWidth));
        int hudY = Math.max(0, Math.min((int) (counter.posY * (field_22790 - hudHeight)), field_22790 - hudHeight));

        boolean onRightEdge = mx >= hudX + hudWidth - EDGE_ZONE && mx <= hudX + hudWidth + 2 && my >= hudY - 2 && my <= hudY + hudHeight + 2;
        boolean onBottomEdge = my >= hudY + hudHeight - EDGE_ZONE && my <= hudY + hudHeight + 2 && mx >= hudX - 2 && mx <= hudX + hudWidth + 2;

        if (onRightEdge || onBottomEdge) {
            resizing = true; resizeAnchorX = hudX; resizeAnchorY = hudY; resizeStartScale = counter.scale; return true;
        }

        if (mx >= hudX - 2 && mx <= hudX + hudWidth + 2 && my >= hudY - 2 && my <= hudY + hudHeight + 2) {
            dragging = true; dragOffsetX = mx - hudX; dragOffsetY = my - hudY; return true;
        }

        return super.method_25402(click, always);
    }

    @Override
    public boolean method_25403(class_11909 click, double dragX, double dragY) {
        if (counter == null) return super.method_25403(click, dragX, dragY);
        double mx = click.comp_4798(), my = click.comp_4799();

        if (resizing) {
            float oldScale = (float) Math.max(0.5, Math.min(2.0, resizeStartScale));
            int oldWidth = CpsHudOverlay.getHudWidth(counter);
            int oldHeight = CpsHudOverlay.getHudHeight(counter);
            double dx = mx - resizeAnchorX, dy = my - resizeAnchorY;
            double baseWidth = oldWidth / oldScale, baseHeight = oldHeight / oldScale;
            if (baseWidth <= 0) baseWidth = 50;
            if (baseHeight <= 0) baseHeight = 20;
            double newScale = Math.max(dx / baseWidth, dy / baseHeight);
            newScale = Math.round(newScale * 10.0) / 10.0;
            counter.scale = Math.max(0.5, Math.min(2.0, newScale));
            return true;
        }

        if (dragging) {
            int hudWidth = CpsHudOverlay.getHudWidth(counter);
            int hudHeight = CpsHudOverlay.getHudHeight(counter);
            int newHudX = Math.max(0, Math.min((int) (mx - dragOffsetX), field_22789 - hudWidth));
            int newHudY = Math.max(0, Math.min((int) (my - dragOffsetY), field_22790 - hudHeight));
            counter.posX = (field_22789 - hudWidth) > 0 ? (double) newHudX / (field_22789 - hudWidth) : 0.0;
            counter.posY = (field_22790 - hudHeight) > 0 ? (double) newHudY / (field_22790 - hudHeight) : 0.0;
            counter.posX = Math.max(0.0, Math.min(1.0, counter.posX));
            counter.posY = Math.max(0.0, Math.min(1.0, counter.posY));
            counter.presetName = detectPresetName(counter.posX, counter.posY);
            return true;
        }

        return super.method_25403(click, dragX, dragY);
    }

    @Override
    public boolean method_25406(class_11909 click) {
        if (dragging) { dragging = false; ModConfig.getConfig().save(); return true; }
        if (resizing) { resizing = false; ModConfig.getConfig().save(); return true; }
        return super.method_25406(click);
    }

    private String detectPresetName(double posX, double posY) {
        if (Math.abs(posX) < 0.01 && Math.abs(posY) < 0.01) return "Top-Left";
        if (Math.abs(posX - 1.0) < 0.01 && Math.abs(posY) < 0.01) return "Top-Right";
        if (Math.abs(posX) < 0.01 && Math.abs(posY - 1.0) < 0.01) return "Bottom-Left";
        if (Math.abs(posX - 1.0) < 0.01 && Math.abs(posY - 1.0) < 0.01) return "Bottom-Right";
        return "Custom";
    }

    @Override
    public void method_25419() {
        CpsHudOverlay.setSnappingActive(false);
        ModConfig.getConfig().save();
        if (field_22787 != null) field_22787.method_1507(parent);
    }

    @Override
    public boolean method_25421() { return false; }
}
