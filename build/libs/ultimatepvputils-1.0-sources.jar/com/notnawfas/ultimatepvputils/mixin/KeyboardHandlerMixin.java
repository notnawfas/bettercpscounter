package com.notnawfas.ultimatepvputils.mixin;

import com.notnawfas.ultimatepvputils.cps.CpsTracker;
import net.minecraft.class_11908;
import net.minecraft.class_309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_309.class)
public class KeyboardHandlerMixin {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void onKey(long window, int key, class_11908 keyInput, CallbackInfo ci) {
        CpsTracker.INSTANCE.onKeyPress(keyInput.comp_4795(), key);
    }
}
